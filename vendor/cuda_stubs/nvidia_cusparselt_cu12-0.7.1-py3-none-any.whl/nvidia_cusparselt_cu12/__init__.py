"""Stub package. CUDA shared libs must be provided by system installation."""
